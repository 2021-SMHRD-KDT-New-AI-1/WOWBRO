package com.jkh.wowbro2.HomeAdapter;

public class FeaturedHelperClass {

    int image;
    String title;

    public FeaturedHelperClass(int image, String title) {
        this.image = image;
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }
}
